/**
 * api/server.ts -- GoldenMatch REST API server (node:http).
 *
 * Node-only: uses node:http, node:path. NOT edge-safe.
 *
 * Endpoints:
 *   GET  /health                     - liveness check
 *   POST /dedupe                     - dedupe a batch of rows (JSON body)
 *   POST /match                      - match target vs reference
 *   POST /score                      - score two strings
 *   POST /explain                    - explain a pair
 *   POST /profile                    - profile a batch of rows
 *   POST /clusters                   - return clusters from dedupe
 *   GET  /reviews                    - list pending review items
 *   POST /reviews/decide             - accept/reject a review item
 *
 * Ports ideas from goldenmatch/api/server.py.
 */

import {
  createServer,
  type IncomingMessage,
  type ServerResponse,
} from "node:http";
import { resolve, isAbsolute, sep } from "node:path";
import { dedupe, match, scoreStrings } from "../../core/api.js";
import type { Row } from "../../core/types.js";
import {
  makeMatchkeyConfig,
  makeMatchkeyField,
} from "../../core/types.js";
import { explainPair } from "../../core/explain.js";
import { profileRows } from "../../core/profiler.js";

// ---------------------------------------------------------------------------
// In-memory review queue
// ---------------------------------------------------------------------------

interface ReviewItem {
  readonly id: string;
  readonly idA: number;
  readonly idB: number;
  readonly score: number;
  readonly rowA: Row;
  readonly rowB: Row;
  status: "pending" | "accepted" | "rejected";
  decidedAt?: string;
}

class ReviewQueue {
  private items = new Map<string, ReviewItem>();

  enqueue(item: Omit<ReviewItem, "status" | "id"> & { id?: string }): ReviewItem {
    const id = item.id ?? `${item.idA}:${item.idB}`;
    const rec: ReviewItem = {
      id,
      idA: item.idA,
      idB: item.idB,
      score: item.score,
      rowA: item.rowA,
      rowB: item.rowB,
      status: "pending",
    };
    this.items.set(id, rec);
    return rec;
  }

  pending(): ReviewItem[] {
    return [...this.items.values()].filter((r) => r.status === "pending");
  }

  decide(id: string, accept: boolean): ReviewItem | null {
    const existing = this.items.get(id);
    if (!existing) return null;
    existing.status = accept ? "accepted" : "rejected";
    existing.decidedAt = new Date().toISOString();
    return existing;
  }

  all(): ReviewItem[] {
    return [...this.items.values()];
  }
}

const reviewQueue = new ReviewQueue();

// Memory store (Phase 2.4.4): bound by `setServerMemoryStore` from server
// startup or tests. When null, /reviews/decide skips correction writes.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let serverMemoryStore: any = null;

/**
 * Bind a `MemoryStore` to the REST server. When set, `POST /reviews/decide`
 * writes a steward correction (empty hashes) on every decision. Pass `null`
 * to clear.
 */
export function setServerMemoryStore(
  store: import("../../core/memory/types.js").MemoryStore | null,
): void {
  serverMemoryStore = store;
}

// Identity store (Phase 2.5): bound by `setServerIdentityStore`. When set,
// the `/identities/*` routes are live; otherwise they return 503.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let serverIdentityStore: any = null;

/**
 * Bind an `IdentityStore` to the REST server. When set, `GET /identities`,
 * `GET /identities/:id`, etc. are live. Pass `null` to disable.
 */
export function setServerIdentityStore(
  store: import("../../core/identity/types.js").IdentityStore | null,
): void {
  serverIdentityStore = store;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

export function sanitizePath(raw: string): string {
  const resolved = isAbsolute(raw) ? resolve(raw) : resolve(process.cwd(), raw);
  const cwd = resolve(process.cwd());
  // Guard against prefix-bypass: cwd="/app/foo" must NOT accept "/app/foobar".
  if (resolved !== cwd && !resolved.startsWith(cwd + sep)) {
    throw new Error(`Path '${raw}' is outside the working directory`);
  }
  return resolved;
}

async function readBody(req: IncomingMessage): Promise<string> {
  let body = "";
  for await (const chunk of req) {
    body += typeof chunk === "string" ? chunk : (chunk as Buffer).toString("utf8");
  }
  return body;
}

async function readJsonBody(req: IncomingMessage): Promise<Record<string, unknown>> {
  const raw = await readBody(req);
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
      throw new Error("request body must be a JSON object");
    }
    return parsed as Record<string, unknown>;
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    throw new Error(`invalid JSON body: ${msg}`);
  }
}

/** Strip internal Error fields (stack, errno, syscall, code) before
 *  serialising to the wire. Otherwise a thrown Error becomes a JSON
 *  blob with its full V8 stack trace, exposing internal file paths
 *  and library versions to unauthenticated clients. */
function sanitiseForWire(data: unknown): unknown {
  if (data instanceof Error) {
    return { error: data.message };
  }
  if (data && typeof data === "object" && !Array.isArray(data)) {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(data)) {
      if (k === "stack" || k === "errno" || k === "syscall") continue;
      out[k] = v;
    }
    return out;
  }
  return data;
}

function sendJson(res: ServerResponse, status: number, data: unknown): void {
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json");
  res.end(JSON.stringify(sanitiseForWire(data)));
}

function asRowArray(v: unknown, label: string): Row[] {
  if (!Array.isArray(v)) throw new Error(`${label} must be an array of objects`);
  return v as Row[];
}

interface ShorthandOpts {
  exact?: readonly string[];
  fuzzy?: Readonly<Record<string, number>>;
  blocking?: readonly string[];
  threshold?: number;
}

function extractShorthand(body: Record<string, unknown>): ShorthandOpts {
  const out: {
    exact?: readonly string[];
    fuzzy?: Readonly<Record<string, number>>;
    blocking?: readonly string[];
    threshold?: number;
  } = {};
  if (Array.isArray(body["exact"])) out.exact = body["exact"].map(String);
  if (Array.isArray(body["blocking"])) out.blocking = body["blocking"].map(String);
  if (body["fuzzy"] && typeof body["fuzzy"] === "object" && !Array.isArray(body["fuzzy"])) {
    const f: Record<string, number> = {};
    for (const [k, v] of Object.entries(body["fuzzy"] as Record<string, unknown>)) {
      const n = typeof v === "number" ? v : Number(v);
      if (Number.isFinite(n)) f[k] = n;
    }
    out.fuzzy = f;
  }
  if (typeof body["threshold"] === "number") out.threshold = body["threshold"];
  return out;
}

// ---------------------------------------------------------------------------
// Route handlers
// ---------------------------------------------------------------------------

async function handleRequest(
  req: IncomingMessage,
  res: ServerResponse,
): Promise<void> {
  const url = new URL(req.url ?? "/", `http://${req.headers.host ?? "localhost"}`);
  const pathname = url.pathname;
  const method = req.method ?? "GET";

  try {
    if (pathname === "/health" && method === "GET") {
      sendJson(res, 200, { status: "ok", service: "goldenmatch-js" });
      return;
    }

    if (pathname === "/dedupe" && method === "POST") {
      const body = await readJsonBody(req);
      const rows = asRowArray(body["rows"], "rows");
      const options = extractShorthand(body);
      const result = await dedupe(rows, options);
      sendJson(res, 200, {
        stats: {
          total_records: result.stats.totalRecords,
          total_clusters: result.stats.totalClusters,
          match_rate: result.stats.matchRate,
          matched_records: result.stats.matchedRecords,
          unique_records: result.stats.uniqueRecords,
        },
        golden_records: result.goldenRecords,
        dupes: result.dupes,
        unique: result.unique,
      });
      return;
    }

    if (pathname === "/match" && method === "POST") {
      const body = await readJsonBody(req);
      const target = asRowArray(body["target"], "target");
      const reference = asRowArray(body["reference"], "reference");
      const options = extractShorthand(body);
      const result = await match(
        target.map((r) => ({ ...r, __source__: "target" })),
        reference.map((r) => ({ ...r, __source__: "reference" })),
        options,
      );
      sendJson(res, 200, {
        matched: result.matched,
        unmatched: result.unmatched,
        stats: result.stats,
      });
      return;
    }

    if (pathname === "/score" && method === "POST") {
      const body = await readJsonBody(req);
      const a = String(body["a"] ?? "");
      const b = String(body["b"] ?? "");
      const scorer = typeof body["scorer"] === "string" ? (body["scorer"] as string) : "jaro_winkler";
      sendJson(res, 200, { scorer, score: scoreStrings(a, b, scorer) });
      return;
    }

    if (pathname === "/explain" && method === "POST") {
      const body = await readJsonBody(req);
      const rowA = body["row_a"] as Row | undefined;
      const rowB = body["row_b"] as Row | undefined;
      if (!rowA || !rowB) throw new Error("row_a and row_b are required");
      const fieldsRaw = body["fields"];
      if (!Array.isArray(fieldsRaw)) {
        throw new Error("fields must be an array");
      }
      const fields = fieldsRaw.map((entry) => {
        if (!entry || typeof entry !== "object") {
          throw new Error("each field must be an object");
        }
        const e = entry as Record<string, unknown>;
        if (typeof e["field"] !== "string") {
          throw new Error("each field needs a 'field' property");
        }
        return makeMatchkeyField({
          field: e["field"] as string,
          transforms: Array.isArray(e["transforms"])
            ? (e["transforms"] as unknown[]).map(String)
            : ["lowercase", "strip"],
          scorer: typeof e["scorer"] === "string" ? (e["scorer"] as string) : "jaro_winkler",
          weight: typeof e["weight"] === "number" ? (e["weight"] as number) : 1.0,
        });
      });
      const threshold = typeof body["threshold"] === "number" ? (body["threshold"] as number) : 0.85;
      const mk = makeMatchkeyConfig({
        name: "adhoc",
        type: "weighted",
        fields,
        threshold,
      });
      const explanation = explainPair(rowA, rowB, mk);
      sendJson(res, 200, {
        score: explanation.score,
        confidence: explanation.confidence,
        explanation: explanation.explanation,
        field_scores: explanation.fieldScores,
      });
      return;
    }

    if (pathname === "/profile" && method === "POST") {
      const body = await readJsonBody(req);
      const rows = asRowArray(body["rows"], "rows");
      const profile = profileRows(rows);
      sendJson(res, 200, {
        row_count: profile.rowCount,
        columns: profile.columns.map((c) => ({
          name: c.name,
          inferred_type: c.inferredType,
          null_count: c.nullCount,
          null_rate: c.nullRate,
          distinct_count: c.distinctCount,
          cardinality_ratio: c.cardinalityRatio,
          avg_length: c.avgLength,
          max_length: c.maxLength,
          sample_values: c.sampleValues,
        })),
      });
      return;
    }

    if (pathname === "/clusters" && method === "POST") {
      const body = await readJsonBody(req);
      const rows = asRowArray(body["rows"], "rows");
      const options = extractShorthand(body);
      const result = await dedupe(rows, options);
      const clusters: Array<{
        cluster_id: number;
        size: number;
        confidence: number;
        quality: string;
        members: readonly number[];
      }> = [];
      for (const [cid, info] of result.clusters.entries()) {
        clusters.push({
          cluster_id: cid,
          size: info.size,
          confidence: info.confidence,
          quality: info.clusterQuality,
          members: info.members,
        });
      }
      sendJson(res, 200, {
        cluster_count: clusters.length,
        clusters,
      });
      return;
    }

    if (pathname === "/reviews" && method === "GET") {
      sendJson(res, 200, { pending: reviewQueue.pending() });
      return;
    }

    if (pathname === "/reviews/decide" && method === "POST") {
      const body = await readJsonBody(req);
      const id = String(body["id"] ?? "");
      const accept = Boolean(body["accept"]);
      if (id === "") throw new Error("id is required");
      const decided = reviewQueue.decide(id, accept);
      if (!decided) {
        sendJson(res, 404, { error: `review item ${id} not found` });
        return;
      }
      // Memory collection (Phase 2.4.4): if a serverMemoryStore is bound,
      // write a steward correction with EMPTY hashes (REST has no df).
      if (serverMemoryStore !== null) {
        try {
          const { trustForSource } = await import("../../core/memory/types.js");
          await serverMemoryStore.addCorrection({
            id: crypto.randomUUID(),
            idA: Math.min(decided.idA, decided.idB),
            idB: Math.max(decided.idA, decided.idB),
            decision: accept ? "approve" : "reject",
            source: "steward",
            trust: trustForSource("steward"),
            fieldHash: "",
            recordHash: "",
            originalScore: decided.score,
            matchkeyName: null,
            reason: null,
            dataset: null,
            createdAt: new Date(),
          });
        } catch (err) {
          // Never fail the REST decision because memory write failed.
          // eslint-disable-next-line no-console
          console.warn(
            `Memory write failed for /reviews/decide ${id}: ${
              err instanceof Error ? err.message : String(err)
            }`,
          );
        }
      }
      sendJson(res, 200, { decided });
      return;
    }

    if (pathname === "/reviews/enqueue" && method === "POST") {
      const body = await readJsonBody(req);
      const idA = Number(body["id_a"]);
      const idB = Number(body["id_b"]);
      const score = Number(body["score"]);
      const rowA = body["row_a"] as Row | undefined;
      const rowB = body["row_b"] as Row | undefined;
      if (!Number.isFinite(idA) || !Number.isFinite(idB) || !rowA || !rowB) {
        throw new Error("id_a, id_b, row_a, row_b are required");
      }
      const item = reviewQueue.enqueue({
        idA,
        idB,
        score: Number.isFinite(score) ? score : 0,
        rowA,
        rowB,
      });
      sendJson(res, 200, { item });
      return;
    }

    // ----- Identity Graph routes ------------------------------------------
    // Mirrors `goldenmatch.web.routers.identity` (Python). Routes guard on
    // serverIdentityStore being bound; otherwise 503 with hint.
    if (pathname.startsWith("/identities") && method === "GET") {
      if (!serverIdentityStore) {
        sendJson(res, 503, {
          error: "IdentityStore not bound to server",
          hint: "call setServerIdentityStore(store) at startup",
        });
        return;
      }
      const sub = pathname.slice("/identities".length);
      // Order matters: more-specific paths before /:id wildcard.
      if (sub === "/conflicts") {
        const dataset = url.searchParams.get("dataset") ?? undefined;
        const conflicts = await serverIdentityStore.findConflicts(dataset);
        sendJson(res, 200, { conflicts });
        return;
      }
      if (sub === "" || sub === "/") {
        const dataset = url.searchParams.get("dataset") ?? undefined;
        const status = url.searchParams.get("status") ?? undefined;
        const limit = Number(url.searchParams.get("limit") ?? "50");
        const offset = Number(url.searchParams.get("offset") ?? "0");
        const opts: Record<string, unknown> = { limit, offset };
        if (dataset !== undefined) opts["dataset"] = dataset;
        if (status !== undefined) opts["status"] = status;
        const items = await serverIdentityStore.listIdentities(opts);
        sendJson(res, 200, { items, limit, offset });
        return;
      }
      // /identities/:id  or  /identities/:id/history
      const parts = sub.split("/").filter((s) => s.length > 0);
      const entityId = parts[0];
      if (entityId && parts.length === 1) {
        const node = await serverIdentityStore.getIdentity(entityId);
        if (!node) {
          sendJson(res, 404, { error: `Not found: ${entityId}` });
          return;
        }
        const records = await serverIdentityStore.getRecordsForEntity(entityId);
        const edges = await serverIdentityStore.edgesForEntity(entityId);
        const events = await serverIdentityStore.history(entityId);
        sendJson(res, 200, { node, records, edges, events });
        return;
      }
      if (entityId && parts[1] === "history" && parts.length === 2) {
        const limit = Number(url.searchParams.get("limit") ?? "50");
        const events = await serverIdentityStore.history(entityId, limit);
        sendJson(res, 200, { events });
        return;
      }
    }

    if (pathname === "/identities/merge" && method === "POST") {
      if (!serverIdentityStore) {
        sendJson(res, 503, { error: "IdentityStore not bound to server" });
        return;
      }
      const body = await readJsonBody(req);
      const keep = typeof body["keep"] === "string" ? (body["keep"] as string) : "";
      const absorb =
        typeof body["absorb"] === "string" ? (body["absorb"] as string) : "";
      if (!keep || !absorb) {
        throw new Error("'keep' and 'absorb' entity IDs are required");
      }
      const { manualMerge } = await import("../../core/identity/query.js");
      const result = await manualMerge(serverIdentityStore, keep, absorb);
      sendJson(res, 200, result);
      return;
    }

    if (pathname === "/identities/split" && method === "POST") {
      if (!serverIdentityStore) {
        sendJson(res, 503, { error: "IdentityStore not bound to server" });
        return;
      }
      const body = await readJsonBody(req);
      const entityId =
        typeof body["entity_id"] === "string" ? (body["entity_id"] as string) : "";
      const rawRecordIds = body["record_ids"];
      if (!Array.isArray(rawRecordIds)) {
        throw new Error("'record_ids' must be an array");
      }
      const recordIds = rawRecordIds.map((v) => String(v));
      if (!entityId || recordIds.length === 0) {
        throw new Error("'entity_id' and non-empty 'record_ids' are required");
      }
      const { manualSplit } = await import("../../core/identity/query.js");
      const result = await manualSplit(serverIdentityStore, entityId, recordIds);
      sendJson(res, 200, result);
      return;
    }

    sendJson(res, 404, { error: `Not found: ${method} ${pathname}` });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    sendJson(res, 500, { error: msg });
  }
}

// ---------------------------------------------------------------------------
// Public: startApiServer
// ---------------------------------------------------------------------------

export interface StartApiOptions {
  readonly port?: number;
  readonly host?: string;
}

/**
 * Start the REST API server.
 * Default: http://127.0.0.1:8000.
 *
 * Returns the http.Server so tests can close it.
 */
export function startApiServer(options: StartApiOptions = {}): ReturnType<typeof createServer> {
  const port = options.port ?? 8000;
  const host = options.host ?? "127.0.0.1";
  const server = createServer((req, res) => {
    handleRequest(req, res).catch((err: unknown) => {
      const msg = err instanceof Error ? err.message : String(err);
      console.warn("Unhandled request error:", msg);
      try {
        if (!res.headersSent) {
          res.statusCode = 500;
          res.setHeader("Content-Type", "application/json");
          res.end(JSON.stringify({ error: msg }));
        }
      } catch (writeErr) {
        // Response already committed or socket closed — log and move on.
        // eslint-disable-next-line no-console
        console.warn(
          "Failed to write API error response:",
          writeErr instanceof Error ? writeErr.message : String(writeErr),
        );
      }
    });
  });
  server.listen(port, host, () => {
    // eslint-disable-next-line no-console
    console.log(`GoldenMatch API listening on http://${host}:${port}`);
  });
  return server;
}

export { reviewQueue, ReviewQueue };
